# License
Copyright 2019 - 2021 Raul Alejandro Vargas Acosta, Ruey Long Cheu, Natalia Villanueva Rosales, Guillermina Gina Nunez-Mchiri at The University of Texas at El Paso

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

# Disclaimer
The contents of this application reflect the views of the authors, who are responsible for the facts and the accuracy of the information presented herein. This application is disseminated in the interest of information exchange. This work is funded, partially or entirely, by a grant from the U.S. Department of Transportation’s University Transportation Centers Program. However, the U.S. Government assumes no liability for the contents or use thereof.

# Acknowledgments
The Urban Connector development team thanks Josue David Lopez, Dr. Okan Gurbuz, Diana Becerra, Emiliano Ruiz, Ruth Priscilla Granados, and Fernie Briones for the useful discussions during the development of the Urban Connector Release Candidate 1.0
